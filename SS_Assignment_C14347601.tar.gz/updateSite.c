#include <sys/stat.h>
#include <sys/types.h>
#include "updateSite.h"
#include "globals.h"
#include "timeUtil.h"


extern int errno;

char* get_latestFile();

char* remove_spaces( char *str);

void copyToSite(char *path );

char* getUpdatesFileName();

bool updateWebsite()
{
  printf("\n updateWebsite called\n");
  // Write Update Started message to Message Queue
  char latest_file[80];
  char line[80];
  char command[100];	


  mqd_t mq;
  char queueBuffer[1024];
  strcpy(queueBuffer, "");

  //open message queue
  mq =mq_open("des_queue", O_WRONLY);


  strcpy(command,"ls -t ");
  strcat(command,MODIFIED_LOGS_FOLDER);
  strcat(command,"/*.* | head -1 ");

  printf("\n ls Command : %s\n", command);

  strcpy(latest_file,"");
  //strcat(latest_file, get_latestFile());

  // Open file for updates

  
  FILE *fp = popen(command,"r");
  // FILE *fp = popen("ls /var/liveSite/logs" ,"r");
  while (fgets(line,sizeof(line),fp) != NULL){

    //printf("\nLine Buffer: %sEOF" , line);
    strcpy(line,remove_spaces(line));
    strcpy(latest_file,line);
    
    printf("\nLatest File : %s EOF\n" , latest_file);
    //strcpy(result, latest_file);
   
       
  }

  //  printf(" Now latest file = %s", latest_file);

  // Read from latest_file 
  printf ("\n Attempting to open %s \n", latest_file);

  
  FILE *fileUpdate = fopen(getUpdatesFileName(), "w");
  fprintf(fileUpdate,"Updated Files on %s\n",getTStamp());

  printf("Got here updateSite fopen\n");
  
  FILE *fileP = fopen(latest_file, "r");
  if (fileP != NULL) {
    FILE *fpCp;    // File Pointer for popen cp command
    char line[256];
    char buffer[256];
    char *tmpStr;
    char *fileN;
 
    while (fgets(line, sizeof(line), fileP)){
      printf("%s\n",line);
      tmpStr = strdup(line);
      // Get the first element in the tokenised string
      char *path =strsep(&tmpStr,":");

      
      // Check if path is a file
      struct stat path_stat;
      stat(path, &path_stat);
      
      if (S_ISREG(path_stat.st_mode))	{
	printf("File path : %s\n",path);
	fileN = basename(path);   
	printf("File Name : %s\n",fileN);

	// Copy file to live site
	strcpy(command,"cp ");
	strcat(command, path);
	strcat(command," ");
	strcat(command,LIVESITE_FOLDER);
	if ((fpCp = popen(command,"r")) !=NULL) {
	    printf("%s  Copied to Site\n" , path);	


	    char livePath[90];
	    // Write file to list of updates
	    strcpy(livePath,LIVESITE_FOLDER);
	    strcat(livePath,"/");
	    strcat(livePath,fileN);
	    printf("%s Live Site File\n" , livePath);	
	    fprintf(fileUpdate, "%s\n", livePath);
	  } else {
	    printf ("\nError executing : %s", command);  
	  }
	  
	//fprintf(fp_mod,"%s", buff);

      } else{
	printf("\n%s does not exist\n", fileN);
      }
    }
    
    // Close File Pointers
    fclose(fileUpdate);
    fclose(fileP);
  
  }
  else { // Error Reading File  
    fprintf(stderr , "Value of errno:  %d\n", errno);
    perror("Error is ");
    fprintf(stderr , "Error opening file  %s\n", strerror(errno));
  }
    //  For each file (path) in the array carry out a copy of that file to its same location but on the live site 
    // i.e. remove the file name only from the path using basename(path) and copy to LIVESITE_FOLDER
  
  
    
    // Write Update finished message to message queue
    strcat(queueBuffer, "update complete");
    memset(queueBuffer, 0, 1024);
    mq_send(mq, queueBuffer, 1024, 0);

}


char* remove_spaces( char *str)
{
  char *end;

  while( isspace((unsigned char ) *str)) str++;

  if (*str==0)
    return str;

  // Trim training spaces
  end = str+strlen(str)-1;
  while ( end > str && isspace((unsigned char)*end))end--;

  
  *(end+1)=0;
  
  return str;
}  


void copyToSite(char *path){
  char command[90];
  printf ("File %s", path);
   strcpy(command,"cp ");
   strcat(command, path);
   strcat(command," ");
   strcat(command,LIVESITE_FOLDER);
   FILE *fpCp = popen(command,"r");
   if (fpCp == NULL) {
     printf ("\nError copying file %s" , path);
   }
}


char* getUpdatesFileName(){
  static char buffer[80];

  strcpy(buffer,UPDATE_FOLDER);
  strcat(buffer,"Updated_Files_");
  strcat(buffer,getTStamp());
  strcat(buffer,".txt");
  printf ("Update File name %s", buffer);
  return buffer;
}
