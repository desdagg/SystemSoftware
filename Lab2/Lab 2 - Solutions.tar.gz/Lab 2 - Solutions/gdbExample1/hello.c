#include <stdio.h>

int main() {
   
   int age;
   
   printf("Enter your age:");

   scanf("%d", &age);
    
}
