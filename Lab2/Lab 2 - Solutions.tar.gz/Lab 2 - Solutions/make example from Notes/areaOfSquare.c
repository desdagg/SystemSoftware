#include "areaOfRectangle.h"

int areaOfSquare(int length) { 
   int area;
   
   area = areaOfRectangle(length, length);
   
   return area;
}
