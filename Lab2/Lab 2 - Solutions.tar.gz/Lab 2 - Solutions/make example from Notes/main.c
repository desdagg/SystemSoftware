#include <stdio.h>
#include<math.h>


int main( int argc, char *argv[] )  {
   int aor;

   aor = areaOfRectangle(10,80);
   printf("Area of Recctangle: %d", aor);
}
