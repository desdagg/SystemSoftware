#ifndef AREAOFSQUARE_H_
#define AREAOFSQUARE_H_

int areaOfSquare(int length);

#endif //  AREAOFSQUARE_H_
