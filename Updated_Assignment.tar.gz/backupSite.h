// Utility functions related to auditing and reporting the changes to the web site since the last update

#ifndef BACKUPSITE_H_
#define BACKUPSITE_H_

#include <stdio.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <stdbool.h>
#include <mqueue.h>  // for the queue

void backupSite();

char* getBkpTStamp();

char* getBackupCommand();

char* getChmodCommand(int lock);

#endif // BACKUPSITE_H_
