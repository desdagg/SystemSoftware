// Website Update Daemon Process

#include<stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>
#include <stdlib.h>
#include <syslog.h>
#include <sys/stat.h>
#include <time.h>
#include <math.h>
#include <stdbool.h>
#include <fcntl.h>
#include <mqueue.h>

#include "globals.h"
#include "reportUtil.h"
#include "updateSite.h"
#include "backupSite.h"

#define MAX_BUF 1024


bool first_run = true;
bool isTestRun = true;

double getSleepTime();
 
int main()
{
	time_t now;
	double sleepTime;

	int fd;
	char * fifoFile = "/home/des/Documents/systemSoftware/assignment/assign/tmp/manualBackup";
	char pipeBuff[MAX_BUF];
	time(&now);  /* get current time; same as: now = time(NULL)  */


	//set up message queue
	mqd_t mq;
	struct mq_attr queue_attributes;
	char queueBuffer[1024+1];
	int terminate = 0;

	//set attributes
	queue_attributes.mq_flags = 0;
	queue_attributes.mq_maxmsg = 10;
	queue_attributes.mq_msgsize = 1024;
	queue_attributes.mq_curmsgs = 0;

	//create queue
	mq = mq_open("/des_queue", O_CREAT | O_RDONLY, 0644, &queue_attributes);


	// Create a child process      
	int pid = fork();
 
	if (pid > 0) {
		// if PID > 0 :: this is the parent
		// this process performs printf and finishes 
		printf("Parent process\n");

	sleep(10);  // uncomment to wait 10 seconds before process ends
	  
		exit(EXIT_SUCCESS);
	} else if (pid == 0) {
	   // Step 1: Create the orphan process
	   printf("Child process\n");
	   
	   // Step 2: Elevate the orphan process to session leader, to loose controlling TTY
	   // This command runs the process in a new session
	   if (setsid() < 0) { exit(EXIT_FAILURE); }

	   // We could fork here again , just to guarantee that the process is not a session leader
	   /*
	   int pid = fork();
	   if (pid > 0) {
		  exit(EXIT_SUCCESS);
	   } else {
	   */
		  // Step 3: call umask() to set the file mode creation mask to 0
		  // This will allow the daemon to read and write files 
		  // with the permissions/access required 
		  umask(0);

		  // Step 4: Change the current working dir to root.
		  // This will eliminate any issues of running on a mounted drive, 
		  // that potentially could be removed etc..
		  if (chdir("/") < 0 ) { exit(EXIT_FAILURE); }

		  // Step 5: Close all open file descriptors
		  /* Close all open file descriptors */
		  int x;
		  for (x = sysconf(_SC_OPEN_MAX); x>=0; x--)
		  {
			 //close (x);
		  } 

		  // Signal Handler goes here  #TODO

		  // Log file goes here        #TODO

		  // Orphan Logic goes here!! 
		  // Keep process running with infinite loop
		  // When the parent finishes after 10 seconds, 
		  // the getppid() will return 1 as the parent (init process)
		 
		  while(1) {
		 sleep(1);
			 printf("child 1: my parent is: %i\n", getppid());
		 
		  time_t now;
		  struct tm nowTime;
		  struct tm runTime;
		  double seconds;
			  
		  int t_sfer = 0;
		  int b_kp = 0;

		  time(&now);  
		  nowTime = runTime = *localtime(&now);

		  seconds =difftime(now,mktime(&runTime));
		  

		 
		 // Set up the rules for the audit daemon (auditd)
		 /*if (first_run) {
		   setAuditRule();
		 }*/
		
		 /*if(seconds == 0){
				printf("\n\n in the seconds \n\n");
				b_kp = 1;
		 }*/
		
		 fd = open(fifoFile, O_RDONLY);
		 read(fd, pipeBuff, MAX_BUF);
		 close(fd);
		if(!strcmp(pipeBuff, "Backup"))
		{
			printf("\n***\nBackup selected\n***\n");
			b_kp = 1;
		 }else if (!strcmp(pipeBuff,"Transfer"))
		{
			printf("\n***\nTransfer selected\n***\n");
			t_sfer = 1;
		}
		
		 // Initiate backup of web site 
		if(b_kp == 1)
		{
			printf("\n***\nBackup started\n***\n");
		 	backupSite();
			t_sfer =1;
			b_kp = 0;
		}
		  
		if(t_sfer == 1)
		{
			printf("\n***\nTransfer started\n***\n");
			// Report on the modified files since the last update
		 	reportModifiedFiles();
		 	// Update production site with new / modified files
			 updateWebsite();

			 do{
				printf("\n\nQueue do while loop\n\n");
				ssize_t bytes_read;
				//receive message
				bytes_read = mq_receive(mq, queueBuffer, 1024,NULL);
				queueBuffer[bytes_read] = '\0';
				if(!strncmp(queueBuffer, "update complete", strlen("update complete")))
				{ 
					printf("\nupdated successfully\n");
					terminate = 1;
				}else{
					printf("\nupdated failed\n");
					terminate = 1;
				}
			}while (!terminate);

			 t_sfer = 0;
		 }
		 //close(fd);
		 //exit(EXIT_SUCCESS);

		 //clear pipeBuff
		 strcpy(pipeBuff, "");
		}
	  //}
	}
 
	return 0;
}

	/*
double getSleepTime(){
  printf("getSleepTime called\n");

  if (first_run) {
   

	time_t now;
	struct tm nowTime;
	struct tm runTime;

	double seconds;
	time(&now);  
	nowTime = runTime = *localtime(&now);
 
	if (isTestRun) 
	  {
	runTime.tm_min = nowTime.tm_min+2; // Start 2 minutes later        
	  }
	else 
	  {
	runTime.tm_hour = START_HOUR; 
	runTime.tm_min = START_MIN; 
	  }

	runTime.tm_sec = 0;

	printf("Now Time %d : %d \n", nowTime.tm_hour , nowTime.tm_min , nowTime.tm_sec);
	//printf("Now Time %d : %d \n", (now/3600)%24,(now/60)%60 );
	printf("Run Time %d : %d ", runTime.tm_hour , runTime.tm_min);

	seconds =fabs(difftime(now,mktime(&runTime))
	printf("\nSleeping  for  %.f", seconds);
	first_run = false;
	return seconds;
  }
  else{
	return 60;
  }

};

	*/

char* getTimeStamp(struct tm myTime){
  time_t rawtime;
  struct tm *info;
  static char buffer[80];
  
  time( &rawtime );
  
  info = localtime( &rawtime );
  
  strftime(buffer , 80,"%x %X", info);
  printf("Formatted date & time : |%s|\n", buffer );
  return buffer;

}
