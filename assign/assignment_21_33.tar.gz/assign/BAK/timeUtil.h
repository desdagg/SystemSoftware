// Utility functions related to time

#ifndef TIMEUTIL_H_
#define TIMEUTIL_H_

#include <unistd.h>
#include <time.h>
#include <stdio.h>
#include <math.h>
#include <stdbool.h>


double getSleepTime(bool first_run);

char* getTStamp();

#endif //  TIMEUTIL_H_
