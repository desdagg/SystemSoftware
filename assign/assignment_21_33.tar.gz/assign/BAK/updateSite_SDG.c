#include "updateSite.h"
#include "globals.h"

extern int errno;

char* get_latestFile();

char* remove_spaces( char *str);

bool updateWebsite()
{
  printf("\n updateWebsite called\n");
  // Write Update Started message to Message Queue
  char latest_file[80];

  strcpy(latest_file,"");
  strcat(latest_file, get_latestFile());
  printf(" Now latest file = %s", latest_file);

  // Read from latest_file 
  printf ("\n Attempting to open %s ", latest_file);
  //strcpy(latest_file, "/var/liveSite/logs/Files_Modified_2018-03-17_21_56_25.txt");
  
  FILE *fileP = fopen(latest_file, "r");
  if (fileP != NULL) {
  
    char line[256];
    char *tmpStr;
    char *fileN;

 
    while (fgets(line, sizeof(line), fileP)){
      printf("%s\n",line);
      // Get the first element in the tokenised string
      char *path =strsep(&tmpStr,":");
      // Add the file name to an array ONLY if it is not already listed
      printf("File path : %s\n",path);
      fileN = basename(path);   
      printf("File Name : %s\n",path);
    }
  }
  else { // Error Reading File  
    fprintf(stderr , "Value of errno:  %d\n", errno);
    perror("Error is ");
    fprintf(stderr , "Error opening file  %s\n", strerror(errno));
  }
    //  For each file (path) in the array carry out a copy of that file to its same location but on the live site 
    // i.e. remove the file name only from the path using basename(path) and copy to LIVESITE_FOLDER
    
  
    
    // Write Update finished message to message queue
    

}



char*  get_latestFile()
{
  // Read list of files from latest Modified_files_ file inMODIFIED_LOGS_FOLDER
  char line[100];
  char latest_file[100];
  //char *latest_file;
  char command[100];
  unsigned int size = 0;
  
  strcpy(command,"ls -t ");
  strcat(command,MODIFIED_LOGS_FOLDER);
  strcat(command,"/*.* | head -1 ");

  printf("\n ls Command : %s\n", command);
  
  FILE *fp = popen(command,"r");
  // FILE *fp = popen("ls /var/liveSite/logs" ,"r");
  while (fgets(line,sizeof(line),fp) != NULL){
    printf("Line Size %ld", sizeof(line));
    printf("\nBuffer %s EOF" , line);
    // Trim line to just text
    strcpy(line, remove_spaces(line));

    strcpy(latest_file,line);
    
    printf("Latest File : %s EOF" , latest_file);
    //strcpy(result, latest_file);
   
       
  }
  return latest_file;
}



char* remove_spaces( char *str)
{
  char *end;

  while( isspace((unsigned char ) *str)) str++;

  if (*str==0)
    return str;

  // Trim training spaces
  end = str+strlen(str)-1;
  while ( end > str && isspace((unsigned char)*end))end--;

  
  *(end+1)=0;
  
  return str;
}  

