#ifndef UPDATESITE_H_
#define UPDATESITE_H_

#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <libgen.h>   // Used for basename(path)
#include <errno.h>
#include <stdlib.h>
#include <ctype.h>   // Used for isspace


bool updateWebsite();

#endif //  UPDATESITE_H_

